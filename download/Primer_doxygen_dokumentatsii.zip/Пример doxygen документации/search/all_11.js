var searchData=
[
  ['_7elist',['~List',['../class_list.html#a76ab9318a0ae5c1383063ef8902a276d',1,'List']]],
  ['_7epeople',['~People',['../class_people.html#a1e0ecf4f81335c8dce9978ca08037534',1,'People']]],
  ['_7estudent',['~Student',['../class_student.html#a083fcff62f08f6c755e0da862e8d8944',1,'Student']]]
];
