var searchData=
[
  ['data',['data',['../struct_list_entry.html#a700af752505698be1ed298d1553a9833',1,'ListEntry']]],
  ['deletecurrententity',['deleteCurrentEntity',['../class_list_walker.html#a33d73ab1dceb1697163b05bf0738d8e8',1,'ListWalker']]],
  ['desc',['DESC',['../_list_processor_8h.html#a28bcb54d080656c8ea32774b9e9f4934a65a6d757dbb571ccc3af9706e9a5f607',1,'ListProcessor.h']]]
];
