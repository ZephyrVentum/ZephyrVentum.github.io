var searchData=
[
  ['fio',['fio',['../class_people.html#a2f79a4a78e1128c7f2947efbd5179882',1,'People']]]
];
