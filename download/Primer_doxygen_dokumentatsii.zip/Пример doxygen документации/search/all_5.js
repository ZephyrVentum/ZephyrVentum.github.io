var searchData=
[
  ['getbyhighschool',['getByHighSchool',['../class_list_processor.html#a496c7205acfcbe1b1979ec00a5a93c01',1,'ListProcessor']]],
  ['getcurrententry',['getCurrentEntry',['../class_list_walker.html#a78186c3acd52f6a402f27fe4e2c824e0',1,'ListWalker']]],
  ['getcurrentindex',['getCurrentIndex',['../class_list_walker.html#ab2ca0d3e3a63c234b3a19682ef02b9bb',1,'ListWalker']]],
  ['getfio',['getFio',['../class_people.html#a018f7912d9c9be57ab7d2ba79ddca668',1,'People']]],
  ['gethighschoolname',['getHighSchoolName',['../class_student.html#ab064fc540f0ee079949e42d98ea7b7b5',1,'Student']]],
  ['getinn',['getInn',['../class_people.html#a11f0eb9afe522bb855a506fd6c7b5bac',1,'People']]],
  ['getnewwalker',['getNewWalker',['../class_list.html#aced0ffa7175581c58d9ff938da04886a',1,'List']]]
];
