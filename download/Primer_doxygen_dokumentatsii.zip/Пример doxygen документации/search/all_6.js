var searchData=
[
  ['head',['head',['../class_list.html#aaf60fcd7d7c363d34a0235780f562a1f',1,'List']]],
  ['highschoolname',['highSchoolName',['../class_student.html#a51a48baeaa95687e1734709bd9da9347',1,'Student']]]
];
