var searchData=
[
  ['next',['next',['../struct_list_entry.html#a7a306736ad7618e335c9ccd28ec37b45',1,'ListEntry']]]
];
