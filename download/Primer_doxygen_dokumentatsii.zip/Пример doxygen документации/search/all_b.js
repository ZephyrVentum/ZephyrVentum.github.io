var searchData=
[
  ['operator_3c',['operator&lt;',['../class_people.html#a7fe16fa26ba9da1c855cf2137dedc2c3',1,'People::operator&lt;()'],['../_people_8cpp.html#a7fe16fa26ba9da1c855cf2137dedc2c3',1,'operator&lt;():&#160;People.cpp']]],
  ['operator_3c_3c',['operator&lt;&lt;',['../class_people.html#a716488f6080d848f000529d22f2bf650',1,'People::operator&lt;&lt;()'],['../class_student.html#af79395dee2158eb9261975e67432d615',1,'Student::operator&lt;&lt;()'],['../_people_8cpp.html#a716488f6080d848f000529d22f2bf650',1,'operator&lt;&lt;(ostream &amp;out, const People &amp;people):&#160;People.cpp'],['../_student_8cpp.html#af79395dee2158eb9261975e67432d615',1,'operator&lt;&lt;(ostream &amp;out, const Student &amp;student):&#160;Student.cpp']]],
  ['operator_3e',['operator&gt;',['../class_people.html#a04df8522fcd9884d729d3b9043b6d0be',1,'People::operator&gt;()'],['../_people_8cpp.html#a04df8522fcd9884d729d3b9043b6d0be',1,'operator&gt;():&#160;People.cpp']]],
  ['operator_3e_3e',['operator&gt;&gt;',['../class_people.html#ab9020a6342f2842e9ac2dad7aa505150',1,'People::operator&gt;&gt;()'],['../class_student.html#a042187b4b0b5f841174ffa9fc61cbdff',1,'Student::operator&gt;&gt;()'],['../_people_8cpp.html#ab9020a6342f2842e9ac2dad7aa505150',1,'operator&gt;&gt;(istream &amp;in, People &amp;people):&#160;People.cpp'],['../_student_8cpp.html#a042187b4b0b5f841174ffa9fc61cbdff',1,'operator&gt;&gt;(istream &amp;in, Student &amp;student):&#160;Student.cpp']]],
  ['operator_5b_5d',['operator[]',['../class_list.html#a4b3ab87216f60185a0d2e116a4ccd727',1,'List']]]
];
