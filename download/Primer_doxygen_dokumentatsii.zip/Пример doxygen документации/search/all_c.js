var searchData=
[
  ['people',['People',['../class_people.html',1,'People'],['../class_people.html#a684d3a039bb43afffd0254040292ea04',1,'People::People()'],['../class_people.html#afd248cca0fa44609893c061e2bdce555',1,'People::People(string newFio, long newInn)'],['../class_people.html#a7283db9315bbf9ade5173058f8f1cbf9',1,'People::People(const People &amp;newPeople)']]],
  ['people_2ecpp',['People.cpp',['../_people_8cpp.html',1,'']]],
  ['people_2eh',['People.h',['../_people_8h.html',1,'']]],
  ['prev',['prev',['../struct_list_entry.html#ad5c45215301282770c569f9c70f5456f',1,'ListEntry']]],
  ['print',['print',['../class_list_processor.html#a4d26390d6d89cd84b3660c6fb33f3e4a',1,'ListProcessor']]],
  ['printall',['printAll',['../class_list_processor.html#aae6b5e542e540805e4d2fd8519b7c960',1,'ListProcessor']]]
];
