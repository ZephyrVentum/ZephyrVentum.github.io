var searchData=
[
  ['savetofile',['saveToFile',['../class_list_processor.html#a65dee0afa41eb62ecf02c5b702c24f64',1,'ListProcessor']]],
  ['selftester',['SelfTester',['../class_self_tester.html',1,'']]],
  ['selftester_2ecpp',['SelfTester.cpp',['../_self_tester_8cpp.html',1,'']]],
  ['selftester_2eh',['SelfTester.h',['../_self_tester_8h.html',1,'']]],
  ['setfio',['setFio',['../class_people.html#a5a21ee8af92ea5b3067cf87671630f3f',1,'People']]],
  ['sethighschoolname',['setHighSchoolName',['../class_student.html#af9783ace12bcbbc8b77161a4529c3b3d',1,'Student']]],
  ['setinn',['setInn',['../class_people.html#a45289152864a4c78426c58924b7d65a5',1,'People']]],
  ['showmenu',['showMenu',['../main_8cpp.html#aba5bd9067aa6f261123165a337c7957d',1,'main.cpp']]],
  ['sortbyinn',['sortByInn',['../class_list_processor.html#a3d55df75185c579a59b5ace9d82d7f89',1,'ListProcessor']]],
  ['student',['Student',['../class_student.html',1,'Student'],['../class_student.html#a26ceb532f001722145707442f5f26480',1,'Student::Student()'],['../class_student.html#a37b3ffd85c4d1fdbc0e20b0137fc6a67',1,'Student::Student(const string newFio, long newInn, const string newHighSchoolName)'],['../class_student.html#a0d342e82322deadcbf46dab50dcb6bb4',1,'Student::Student(const Student &amp;newStudent)']]],
  ['student_2ecpp',['Student.cpp',['../_student_8cpp.html',1,'']]],
  ['student_2eh',['Student.h',['../_student_8h.html',1,'']]]
];
