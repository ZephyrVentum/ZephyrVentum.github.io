var searchData=
[
  ['todo_3a_20implement_20me',['TODO: implement me',['../index.html',1,'']]],
  ['tail',['tail',['../class_list.html#a848abdb1bb69d53bb94de261b29a021c',1,'List']]]
];
