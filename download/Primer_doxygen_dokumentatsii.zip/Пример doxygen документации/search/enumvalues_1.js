var searchData=
[
  ['desc',['DESC',['../_list_processor_8h.html#a28bcb54d080656c8ea32774b9e9f4934a65a6d757dbb571ccc3af9706e9a5f607',1,'ListProcessor.h']]]
];
