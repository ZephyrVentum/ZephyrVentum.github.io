var searchData=
[
  ['people',['People',['../class_people.html#a684d3a039bb43afffd0254040292ea04',1,'People::People()'],['../class_people.html#afd248cca0fa44609893c061e2bdce555',1,'People::People(string newFio, long newInn)'],['../class_people.html#a7283db9315bbf9ade5173058f8f1cbf9',1,'People::People(const People &amp;newPeople)']]],
  ['print',['print',['../class_list_processor.html#a4d26390d6d89cd84b3660c6fb33f3e4a',1,'ListProcessor']]],
  ['printall',['printAll',['../class_list_processor.html#aae6b5e542e540805e4d2fd8519b7c960',1,'ListProcessor']]]
];
