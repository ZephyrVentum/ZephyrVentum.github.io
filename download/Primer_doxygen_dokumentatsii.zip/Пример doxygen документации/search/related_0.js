var searchData=
[
  ['operator_3c',['operator&lt;',['../class_people.html#a7fe16fa26ba9da1c855cf2137dedc2c3',1,'People']]],
  ['operator_3c_3c',['operator&lt;&lt;',['../class_people.html#a716488f6080d848f000529d22f2bf650',1,'People::operator&lt;&lt;()'],['../class_student.html#af79395dee2158eb9261975e67432d615',1,'Student::operator&lt;&lt;()']]],
  ['operator_3e',['operator&gt;',['../class_people.html#a04df8522fcd9884d729d3b9043b6d0be',1,'People']]],
  ['operator_3e_3e',['operator&gt;&gt;',['../class_people.html#ab9020a6342f2842e9ac2dad7aa505150',1,'People::operator&gt;&gt;()'],['../class_student.html#a042187b4b0b5f841174ffa9fc61cbdff',1,'Student::operator&gt;&gt;()']]]
];
