var searchData=
[
  ['data',['data',['../struct_list_entry.html#a700af752505698be1ed298d1553a9833',1,'ListEntry']]]
];
