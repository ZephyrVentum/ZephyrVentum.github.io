var searchData=
[
  ['prev',['prev',['../struct_list_entry.html#ad5c45215301282770c569f9c70f5456f',1,'ListEntry']]]
];
