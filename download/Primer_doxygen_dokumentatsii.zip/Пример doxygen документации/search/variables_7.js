var searchData=
[
  ['tail',['tail',['../class_list.html#a848abdb1bb69d53bb94de261b29a021c',1,'List']]]
];
