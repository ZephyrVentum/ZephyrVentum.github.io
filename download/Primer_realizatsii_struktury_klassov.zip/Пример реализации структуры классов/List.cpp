
/**
  * @file List.cpp
  * Реализация класса списка.
  *
  * @author davs
  * @version 0.0.1
  * @date 26-nov-2015
  */

#include "List.h"

List::List() {
    head = new ListEntry();
    tail = new ListEntry();
}

List::~List() {
    // [реализация упущена] удаление промежуточных элементов

    delete head;
    head = NULL;
    delete tail;
    tail = NULL;
}


void List::addEntry(const People *data, int position) {
    // [реализация упущена] добавление элемента в указанную позицию
}

void List::clear() {
    // [реализация упущена] очистка списка
}

void List::removeEntry(int position) {
    // [реализация упущена]
}

ListWalker List::getNewWalker() {
    return ListWalker(head);
}

People &List::operator[](size_t index) {
    // [реализация упущена]

}
