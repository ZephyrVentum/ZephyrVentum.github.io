/**
 * @file ListEntry.h
 * Структура одного элемента списка
 * @author davs
 * @version 0.0.1
 * @date 26-nov-2015
 */

#ifndef COURSEEXAMPLE_LISTENTRY_H
#define COURSEEXAMPLE_LISTENTRY_H

#include "People.h"

/**
 * Элемент двухсвязного списка. Характеризуется ссылками на предыдущий, следующий элементы и на класс с данными.
 * Если элемент находится в начале списка ("голова"), то указатель на предыдущий элемент равен NULL.
 * Если элемент находится в конце списка ("хвост"), то указатель на следующий элемент равен NULL.
 */
struct ListEntry {
    People * data;          ///< Указатель на объект с данными
    ListEntry * next;       ///< Указатель на следующий элемент
    ListEntry * prev;       ///< Указатель на предыдущий элемент
};


#endif //COURSEEXAMPLE_LISTENTRY_H
