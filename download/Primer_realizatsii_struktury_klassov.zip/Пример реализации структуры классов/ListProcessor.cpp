/**
 * @file ListProcessor.cpp
 * Реализация Обработчика списка
 * @author davs
 * @version 0.0.1
 * @date 27-nov-2015
 */

#include "ListProcessor.h"

void ListProcessor::printAll(const List *data) {
    // [реализация упущена]
}

void ListProcessor::print(const List *data, int index) {
    // [реализация упущена]
}

People *ListProcessor::readOne() {
    // [реализация упущена]
    return nullptr;
}

void ListProcessor::saveToFile(string fileName, const List *data) {
    // [реализация упущена]
}

void ListProcessor::readFromFile(string fileName, List *out) {
    // [реализация упущена]
}

void ListProcessor::sortByInn(List *data, ESortOrder sortOrder) {
    // [реализация упущена]
}

void ListProcessor::getByHighSchool(List *data, List *out, string highSchoolName) {
    // [реализация упущена]
}

