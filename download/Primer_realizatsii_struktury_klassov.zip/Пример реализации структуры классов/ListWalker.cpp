/**
 * @file ListWalker.cpp
 * Реализация Бегунка по списку
 * @author davs
 * @version 0.0.1
 * @date 03-dec-2015
 */

#include "ListWalker.h"


ListWalker::ListWalker(ListEntry * newCurrent) {
    current = newCurrent;
}

void ListWalker::deleteCurrentEntity() {
    // [реализация упущена] удаление элемента
}

People *ListWalker::getCurrentEntry() {
    // [реализация упущена] получение элемента по индексу
    return nullptr;
}

void ListWalker::moveCurrentElementForward() {
    // [реализация упущена]
}

void ListWalker::moveCurrentElementBackward() {
    // [реализация упущена]
}

void ListWalker::updateCurrentEntry(People *newData) {
    // [реализация упущена]
}

void ListWalker::insertAfterCurrent(People *newData) {
    // [реализация упущена]
}

size_t ListWalker::getCurrentIndex() {
    // [реализация упущена]
    return -1;
}
