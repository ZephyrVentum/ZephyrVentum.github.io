
/**
  * @file People.cpp
  * Реализация класса жителя.
  *
  * @author davs
  * @version 0.0.1
  * @date 26-nov-2015
  */

#include "People.h"

People::People() : fio(""), inn(0) {  }

People::People(string newFio, long newInn) : fio(newFio), inn(newInn) { }

People::~People() { }

People::People(const People &newPeople) : fio(newPeople.fio), inn(newPeople.inn) { }

const string People::getFio() const {
    return fio;
}

void People::setFio(const string &fio) {
    People::fio = fio;
}

long People::getInn() const {
    return inn;
}

void People::setInn(long inn) {
    People::inn = inn;
}

bool operator<(const People &p1, const People &p2) {
    return false;
}

bool operator>(const People &p1, const People &p2) {
    return false;
}

ostream &operator<<(ostream &out, const People &people) {
    return out;
}

istream &operator>>(istream &in, People &people) {
    return in;
}
