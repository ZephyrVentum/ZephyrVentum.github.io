/**
 * @file SelfTester.cpp
 * Реализация Класса по самотестированию разработанных методов.
 * @author davs
 * @version 0.0.1
 * @date 04-dec-2015
 */

#include "SelfTester.h"
