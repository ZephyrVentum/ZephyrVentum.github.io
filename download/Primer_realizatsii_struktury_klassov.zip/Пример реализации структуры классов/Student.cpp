/**
  * @file Student.cpp
  * Реализация класса студента.
  *
  * @author davs
  * @author xone
  * @version 0.0.1
  * @date 26-nov-2015
  */

#include "Student.h"

Student::Student() : People(), highSchoolName("") { }

Student::Student(const string newFio, long newInn, const string newHighSchoolName)
        : People(newFio, newInn),
        highSchoolName(newHighSchoolName) { }

Student::Student(const Student &newStudent)
        : People(newStudent.getFio(), newStudent.getInn()),
        highSchoolName(newStudent.highSchoolName) { }

Student::~Student() { }

const string Student::getHighSchoolName() const {
    return highSchoolName;
}

void Student::setHighSchoolName(const string highSchoolName) {
    Student::highSchoolName = highSchoolName;
}

ostream &operator<<(ostream &out, const Student &student) {
    return out;
}

istream &operator>>(istream &in, Student &student) {
    return in;
}
