/**
 * @file Student.h
 * Объявление класса - студента.
 * @author davs
 * @version 0.0.1
 * @date 26-nov-2015
 */

#ifndef COURSEEXAMPLE_STUDENT_H
#define COURSEEXAMPLE_STUDENT_H

#include "People.h"

/**
 * Студент - Житель страны, по мимо основных характеристик, обучающийся в ВУЗе
 */
class Student : public People {
private:
    string highSchoolName;      ///< Имя ВУЗа

public:
    /**
     * Конструктор по-улолчанию. Инициализация полей пустыми начальными значениями.
     */
    Student();

    /**
     * Конструктор с параметрами. Инициализация характристик стужента переданными параметрами
     * @param newFio ФИО студента
     * @param newInn идентификационный номер (ИНН) студента
     * @param newHighSchoolName имя ВУЗа студента
     */
    Student(const string newFio, long newInn, const string newHighSchoolName);

    /**
     * Конструктор копирования. Инициализируем студента теми же характеристиками, что и переданный.
     * @param newStudent человек, по образу и подобию которого будем создавать текущего студента
     */
    Student(const Student& newStudent);

    /**
     * Деструктор. Очиска выделенной в конструкторе памяти.
     * В связи с тем, что в конструкторе ничего не выделялось, деструктор - пустой
     */
    virtual ~Student();

    /**
     * Получение имени ВУЗа, в которм учится студент
     * @return имя ВУЗа
     */
    const string getHighSchoolName() const;

    /**
     * Установка нового имени ВУЗа (в который, наверно, студент поступил)
     * @param highSchoolName имя ВУЗа
     */
    void setHighSchoolName(const string highSchoolName);

    /**
     * Вывод информации текущего студента в поток вывода. Функция рассчитана на вывод на экран, по этому имеет
     * следующий формат: '[ИНН (длиной 15 символов)]: [ВУЗ (до 15 символов)] : [FIO]'
     * @param out поток вывода. Так как функция рассчитана на вывод на консоль, то в качестве данного параметра
     * передается переменная <code>cout</code>
     * @param student студента, информация о котором передаем в поток вывода
     * @return поток вывода для дальнейшего вывода данных
     */
    friend ostream& operator << (ostream& out, const Student& student);

    /**
     * Ввод информации текущего студента из потока ввода. Функция рассчитана на ввод с клавиатуры
     * @param in поток ввода. Так как функция рассчитана на ввод с клавиатуры, то в качестве данного параметра
     * передается переменная <code>cin</code>
     * @param student студента, в который занесется информация полученная с потока ввода
     * @return поток ввода для дальнейшего ввода данных
     */
    friend istream& operator >> (istream& in, Student& student);

};


#endif //COURSEEXAMPLE_STUDENT_H
