/**
 * @file main.cpp
 * Файл с точкой входа в программу main.
 * @author davs
 * @version 0.0.1
 * @date 27-nov-2015
 */

/**
 * @mainpage TODO: implement me
 */

#include "List.h"

void showMenu() {
    // TODO: здесь находится реализация метода показа меню, и, возможно,
    // TODO: чтение с клавиатуры и выполнение заданных действий
}

int main() {
    showMenu();
    return 0;
}